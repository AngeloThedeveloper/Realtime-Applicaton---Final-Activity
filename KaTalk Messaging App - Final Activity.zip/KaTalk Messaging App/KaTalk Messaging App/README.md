# KaTalk

KaTalk is a small, responsive messaging app built with plain HTML, CSS, and JavaScript, an Express API, MySQL, and Socket.IO. Accounts, messages, and login sessions are stored in MySQL.

## What it does

- Register and log in with a securely hashed password.
- Start or reopen a private, one-to-one conversation by searching for another account.
- Send, edit, and delete your own messages. Other connected members see message changes immediately.
- Receive live notifications for incoming messages and newly available conversations.
- Search conversations, use the responsive mobile layout, and log out.
- Persist login sessions in MySQL; passwords and message data are not stored in browser local storage.

## Requirements

- Node.js 18 or newer (Node.js 20 LTS is a good choice).
- MySQL 8.0 or a compatible MySQL server.
- A terminal and a web browser. VS Code is recommended.

## Installation

1. Install and start MySQL Server. Create a MySQL account that can create tables in the database (the local `root` account is commonly used for development).
2. Open this project folder in VS Code, then open a terminal in the project folder.
3. Create the database and tables by importing `database/schema.sql`. In Windows PowerShell, if the MySQL command-line client is on your `PATH`, run:

   ```sh
   Get-Content .\database\schema.sql | mysql -u root -p
   ```

   Enter your MySQL password when prompted. In Command Prompt, use `mysql -u root -p < database\schema.sql`. MySQL Workbench also works: open `database/schema.sql` and run the script.
4. Create your local environment file:

   ```sh
   # Windows PowerShell
   Copy-Item .env.example .env
   ```

   Edit `.env` and set `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_NAME` to match your MySQL setup. Replace `SESSION_SECRET` with a long, random private value. Keep `.env` private; it is ignored by Git.
5. Install the app dependencies and start the server:

   ```sh
   npm install
   npm start
   ```

   For development with Node's watch mode, use `npm run dev`.
6. Open [http://localhost:3000](http://localhost:3000). Create an account on the sign-in screen. Have a second account open in another browser or private window to try live chat.

The schema script creates the MySQL session-storage table. The application exits with a clear database connection error if MySQL is not reachable.

## Database

The database is named `katalk`. `database/schema.sql` creates:

- `users`: accounts and bcrypt password hashes.
- `conversations`: direct conversation records.
- `conversation_participants`: user-to-conversation membership and foreign keys.
- `messages`: persistent message content, sender, and creation/update timestamps.
- `katalk_sessions`: expiring server-side login sessions.

Foreign keys cascade when a user or conversation is deleted. There are no pre-created demo accounts; register two accounts to test messaging.

## Troubleshooting

- **Cannot connect to MySQL:** Confirm MySQL Server is running, the database script completed, and `.env` contains the correct host, port, user, password, and database name. The app expects the `katalk` database to exist.
- **Access denied:** Grant the configured MySQL account access to `katalk` and its tables, or use the correct credentials in `.env`.
- **Address already in use:** Stop the other process using port 3000 or set another `PORT` in `.env`.
- **Live messages do not arrive:** Keep both browser sessions online, verify that each account is logged in, and make sure the browser can connect to the same KaTalk server.
- **PowerShell blocks `npm`:** On Windows, try `npm.cmd install` and `npm.cmd start` in PowerShell.

## Project layout

```text
backend/
  db.js
  middleware/auth.js
  routes/auth.js
  routes/chat.js
  server.js
database/
  schema.sql
frontend/
  css/style.css
  index.html
  js/app.js
.env.example
.gitignore
package.json
README.md
```

## Security notes and limitations

Passwords use bcrypt hashing; SQL uses parameterized queries; API routes and Socket.IO rooms check login and conversation membership. Sessions use HTTP-only, same-site cookies and a MySQL-backed session store. For production, deploy behind HTTPS, use a unique secret, and configure secure cookies and database privileges for your hosting environment. This starter app intentionally supports private one-to-one chats only; it does not include group chats, file uploads, or end-to-end encryption.
