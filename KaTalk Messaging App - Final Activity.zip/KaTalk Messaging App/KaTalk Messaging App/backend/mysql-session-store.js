const session = require('express-session');

class MySQLSessionStore extends session.Store {
  constructor(options) {
    super();
    this.pool = options.pool;
  }

  get(sessionId, callback) {
    this.pool.execute(
      'SELECT data FROM katalk_sessions WHERE session_id = ? AND expires > NOW()',
      [sessionId]
    ).then(([rows]) => {
      callback(null, rows.length ? JSON.parse(rows[0].data) : null);
    }).catch(callback);
  }

  set(sessionId, sessionData, callback) {
    const expires = sessionData.cookie && sessionData.cookie.expires
      ? new Date(sessionData.cookie.expires)
      : new Date(Date.now() + 24 * 60 * 60 * 1000);
    this.pool.execute(
      `INSERT INTO katalk_sessions (session_id, expires, data) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE expires = VALUES(expires), data = VALUES(data)`,
      [sessionId, expires, JSON.stringify(sessionData)]
    ).then(() => callback && callback(null)).catch((error) => callback && callback(error));
  }

  touch(sessionId, sessionData, callback) {
    const expires = sessionData.cookie && sessionData.cookie.expires
      ? new Date(sessionData.cookie.expires)
      : new Date(Date.now() + 24 * 60 * 60 * 1000);
    this.pool.execute(
      'UPDATE katalk_sessions SET expires = ? WHERE session_id = ?',
      [expires, sessionId]
    ).then(() => callback && callback(null)).catch((error) => callback && callback(error));
  }

  destroy(sessionId, callback) {
    this.pool.execute('DELETE FROM katalk_sessions WHERE session_id = ?', [sessionId])
      .then(() => callback && callback(null))
      .catch((error) => callback && callback(error));
  }
}

module.exports = MySQLSessionStore;
