const express = require('express');
const pool = require('../db');

const router = express.Router();

function requireUser(req, res) {
  if (!req.session.user) {
    res.status(401).json({ error: 'Authentication required.' });
    return null;
  }
  return req.session.user;
}

async function requireMembership(conversationId, userId) {
  const [rows] = await pool.execute(
    'SELECT 1 FROM conversation_participants WHERE conversation_id = ? AND user_id = ? LIMIT 1',
    [conversationId, userId]
  );
  return rows.length > 0;
}

router.get('/conversations', async (req, res, next) => {
  const user = requireUser(req, res);
  if (!user) return;
  try {
    const [rows] = await pool.execute(
      `SELECT c.id, u.id AS other_id, u.name AS other_name, u.email AS other_email,
              (SELECT body FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_body,
              (SELECT created_at FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_at
       FROM conversations c
       JOIN conversation_participants mine ON mine.conversation_id = c.id AND mine.user_id = ?
       JOIN conversation_participants other ON other.conversation_id = c.id AND other.user_id != ?
       JOIN users u ON u.id = other.user_id
       ORDER BY COALESCE(last_at, c.created_at) DESC`,
      [user.id, user.id]
    );
    res.json({ conversations: rows });
  } catch (error) {
    next(error);
  }
});

router.get('/people', async (req, res, next) => {
  const user = requireUser(req, res);
  if (!user) return;
  try {
    const search = `%${String(req.query.q || '').trim()}%`;
    const [rows] = await pool.execute(
      'SELECT id, name, email FROM users WHERE id != ? AND (name LIKE ? OR email LIKE ?) ORDER BY name LIMIT 20',
      [user.id, search, search]
    );
    res.json({ people: rows });
  } catch (error) {
    next(error);
  }
});

router.post('/conversations', async (req, res, next) => {
  const user = requireUser(req, res);
  if (!user) return;
  const otherId = Number(req.body.userId);
  if (!Number.isSafeInteger(otherId) || otherId <= 0 || otherId === user.id) {
    return res.status(400).json({ error: 'Choose another account.' });
  }
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [existing] = await connection.execute(
      `SELECT c.id FROM conversations c
       JOIN conversation_participants a ON a.conversation_id = c.id AND a.user_id = ?
       JOIN conversation_participants b ON b.conversation_id = c.id AND b.user_id = ?
       LIMIT 1`,
      [user.id, otherId]
    );
    let conversationId;
    if (existing.length) {
      conversationId = existing[0].id;
    } else {
      const [created] = await connection.execute('INSERT INTO conversations () VALUES ()');
      conversationId = created.insertId;
      await connection.execute(
        'INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?), (?, ?)',
        [conversationId, user.id, conversationId, otherId]
      );
    }
    await connection.commit();
    res.status(existing.length ? 200 : 201).json({ conversationId: Number(conversationId) });
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
});

router.get('/conversations/:id/messages', async (req, res, next) => {
  const user = requireUser(req, res);
  if (!user) return;
  const conversationId = Number(req.params.id);
  try {
    if (!await requireMembership(conversationId, user.id)) {
      return res.status(403).json({ error: 'You cannot access this conversation.' });
    }
    const [rows] = await pool.execute(
      `SELECT m.id, m.sender_id, m.body, m.created_at, m.updated_at,
              u.name AS sender_name
       FROM messages m JOIN users u ON u.id = m.sender_id
       WHERE m.conversation_id = ? ORDER BY m.created_at ASC, m.id ASC`,
      [conversationId]
    );
    res.json({ messages: rows });
  } catch (error) {
    next(error);
  }
});

router.post('/conversations/:id/messages', async (req, res, next) => {
  const user = requireUser(req, res);
  if (!user) return;
  const conversationId = Number(req.params.id);
  const body = String(req.body.body || '').trim();
  if (!body) return res.status(400).json({ error: 'Message cannot be empty.' });
  try {
    if (!await requireMembership(conversationId, user.id)) {
      return res.status(403).json({ error: 'You cannot access this conversation.' });
    }
    const [result] = await pool.execute(
      'INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)',
      [conversationId, user.id, body]
    );
    const [rows] = await pool.execute(
      `SELECT m.id, m.conversation_id, m.sender_id, m.body, m.created_at, m.updated_at, u.name AS sender_name
       FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ?`,
      [result.insertId]
    );
    const [participants] = await pool.execute(
      'SELECT user_id FROM conversation_participants WHERE conversation_id = ?',
      [conversationId]
    );
    const io = req.app.get('io');
    const participantRooms = participants.map(({ user_id: participantId }) => `user:${participantId}`);
    io.to(participantRooms).emit('message:new', rows[0]);
    io.to(participantRooms).emit('conversation:updated');
    res.status(201).json({ message: rows[0] });
  } catch (error) {
    next(error);
  }
});

router.patch('/messages/:id', async (req, res, next) => {
  const user = requireUser(req, res);
  if (!user) return;
  const messageId = Number(req.params.id);
  const body = String(req.body.body || '').trim();
  if (!body) return res.status(400).json({ error: 'Message cannot be empty.' });
  try {
    const [rows] = await pool.execute(
      'SELECT id, conversation_id FROM messages WHERE id = ? AND sender_id = ?',
      [messageId, user.id]
    );
    if (!rows.length) return res.status(403).json({ error: 'You cannot edit this message.' });
    await pool.execute('UPDATE messages SET body = ? WHERE id = ?', [body, messageId]);
    req.app.get('io').to(`conversation:${rows[0].conversation_id}`).emit('message:edited', { id: messageId, body });
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

router.delete('/messages/:id', async (req, res, next) => {
  const user = requireUser(req, res);
  if (!user) return;
  const messageId = Number(req.params.id);
  try {
    const [rows] = await pool.execute(
      'SELECT id, conversation_id FROM messages WHERE id = ? AND sender_id = ?',
      [messageId, user.id]
    );
    if (!rows.length) return res.status(403).json({ error: 'You cannot delete this message.' });
    await pool.execute('DELETE FROM messages WHERE id = ?', [messageId]);
    req.app.get('io').to(`conversation:${rows[0].conversation_id}`).emit('message:deleted', { id: messageId });
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
