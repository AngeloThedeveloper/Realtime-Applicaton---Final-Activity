require('dotenv').config();

const path = require('path');
const http = require('http');
const express = require('express');
const session = require('express-session');
const { Server } = require('socket.io');
const pool = require('./db');
const MySQLSessionStore = require('./mysql-session-store');
const authRoutes = require('./routes/auth');
const chatRoutes = require('./routes/chat');

if (!process.env.SESSION_SECRET) {
  throw new Error('SESSION_SECRET is required. Copy .env.example to .env and set a secret.');
}

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const sessionMiddleware = session({
  name: 'katalk.sid',
  secret: process.env.SESSION_SECRET,
  store: new MySQLSessionStore({ pool }),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
});

app.set('io', io);
app.use(express.json({ limit: '16kb' }));
app.use(sessionMiddleware);
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.use('/api/auth', authRoutes);
app.use('/api', chatRoutes);

io.engine.use(sessionMiddleware);
io.use((socket, next) => {
  const user = socket.request.session && socket.request.session.user;
  if (!user) return next(new Error('Authentication required.'));
  socket.user = user;
  next();
});
io.on('connection', (socket) => {
  socket.join(`user:${socket.user.id}`);
  socket.on('conversation:join', async (conversationId) => {
    const id = Number(conversationId);
    if (!Number.isSafeInteger(id) || id <= 0) return;
    try {
      const [membership] = await pool.execute(
        'SELECT 1 FROM conversation_participants WHERE conversation_id = ? AND user_id = ?',
        [id, socket.user.id]
      );
      if (membership.length) socket.join(`conversation:${id}`);
    } catch (error) {
      console.error('Could not verify Socket.IO conversation membership:', error);
    }
  });
});

app.use((error, req, res, next) => {
  console.error(error);
  if (res.headersSent) return next(error);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Not found.' });
});

const port = Number(process.env.PORT || 3000);
pool.query('SELECT 1')
  .then(() => {
    return pool.execute('DELETE FROM katalk_sessions WHERE expires <= NOW()');
  })
  .then(() => {
    server.listen(port, () => {
      console.log(`KaTalk is running at http://localhost:${port}`);
    });
  })
  .catch((error) => {
    console.error('Could not connect to MySQL. Check your .env settings and database setup.', error.message);
    process.exitCode = 1;
  });
