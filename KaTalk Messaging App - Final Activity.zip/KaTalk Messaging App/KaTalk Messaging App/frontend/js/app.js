const state = { user: null, conversations: [], activeId: null, socket: null };

const authScreen = document.querySelector('#authScreen');
const appScreen = document.querySelector('#appScreen');
const authForm = document.querySelector('#authForm');
const nameField = document.querySelector('#nameField');
const authError = document.querySelector('#authError');
let authMode = 'login';

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

function showApp(user) {
  state.user = user;
  authScreen.classList.add('hidden');
  appScreen.classList.remove('hidden');
  document.querySelector('#profileName').textContent = user.name;
  document.querySelector('#profileAvatar').textContent = user.name.charAt(0).toUpperCase();
  state.socket = io();
  state.socket.on('message:new', (message) => {
    if (Number(state.activeId) === Number(message.conversation_id)) {
      loadMessages(state.activeId).catch(() => showToast('Message arrived, but this conversation could not refresh.'));
    }
    loadConversations();
  });
  state.socket.on('message:edited', (message) => { if (state.activeId) loadMessages(state.activeId); });
  state.socket.on('message:deleted', () => { if (state.activeId) loadMessages(state.activeId); });
  state.socket.on('conversation:updated', loadConversations);
  loadConversations();
}

function showAuth() {
  authScreen.classList.remove('hidden');
  appScreen.classList.add('hidden');
}

async function boot() {
  try {
    const data = await api('/api/auth/me');
    showApp(data.user);
  } catch {
    showAuth();
  }
}

document.querySelector('#loginTab').addEventListener('click', () => setAuthMode('login'));
document.querySelector('#registerTab').addEventListener('click', () => setAuthMode('register'));

function setAuthMode(mode) {
  authMode = mode;
  document.querySelector('#loginTab').classList.toggle('active', mode === 'login');
  document.querySelector('#registerTab').classList.toggle('active', mode === 'register');
  document.querySelector('#loginTab').setAttribute('aria-selected', mode === 'login');
  document.querySelector('#registerTab').setAttribute('aria-selected', mode === 'register');
  nameField.classList.toggle('hidden', mode === 'login');
  document.querySelector('#authSubmit').childNodes[0].textContent = mode === 'login' ? 'Log in ' : 'Create account ';
  authError.textContent = '';
}

authForm.addEventListener('submit', async (event) => {
  event.preventEvent?.();
  event.preventDefault();
  authError.textContent = '';
  try {
    const endpoint = authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
    const body = {
      email: document.querySelector('#emailInput').value,
      password: document.querySelector('#passwordInput').value
    };
    if (authMode === 'register') body.name = document.querySelector('#nameInput').value;
    const data = await api(endpoint, { method: 'POST', body: JSON.stringify(body) });
    showApp(data.user);
  } catch (error) {
    authError.textContent = error.message;
  }
});

document.querySelector('#logoutButton').addEventListener('click', async () => {
  await api('/api/auth/logout', { method: 'POST', body: '{}' });
  if (state.socket) state.socket.disconnect();
  location.reload();
});

async function loadConversations() {
  try {
    const data = await api('/api/conversations');
    state.conversations = data.conversations;
    document.querySelector('#chatCount').textContent = data.conversations.length;
    renderConversations(data.conversations);
  } catch (error) {
    console.error(error);
  }
}

function renderConversations(conversations) {
  const list = document.querySelector('#conversationList');
  list.innerHTML = '';
  document.querySelector('#emptyChats').classList.toggle('hidden', conversations.length > 0);
  conversations.forEach((conversation) => {
    const button = document.createElement('button');
    button.className = 'conversation-item';
    button.type = 'button';
    button.innerHTML = `<span class="avatar avatar-peach">${escapeHtml(conversation.other_name.charAt(0).toUpperCase())}</span><span class="conversation-copy"><strong>${escapeHtml(conversation.other_name)}</strong><small>${escapeHtml(conversation.last_body || 'Start the conversation')}</small></span>`;
    button.addEventListener('click', () => openConversation(conversation));
    list.appendChild(button);
  });
}

async function openConversation(conversation) {
  state.activeId = conversation.id;
  document.querySelector('#welcomePanel').classList.add('hidden');
  document.querySelector('#activeChat').classList.remove('hidden');
  document.querySelector('#chatName').textContent = conversation.other_name;
  document.querySelector('#chatAvatar').textContent = conversation.other_name.charAt(0).toUpperCase();
  state.socket.emit('conversation:join', conversation.id);
  await loadMessages(conversation.id);
}

async function loadMessages(conversationId) {
  const data = await api(`/api/conversations/${conversationId}/messages`);
  const messages = document.querySelector('#messages');
  messages.innerHTML = '';
  data.messages.forEach((message) => {
    const own = Number(message.sender_id) === state.user.id;
    const item = document.createElement('div');
    item.className = `message-row ${own ? 'own' : ''}`;
    item.innerHTML = `<div class="message-bubble">${escapeHtml(message.body)}<small>${new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small></div>`;
    if (own) {
      item.addEventListener('dblclick', async () => {
        const next = prompt('Edit message', message.body);
        if (next && next.trim()) await api(`/api/messages/${message.id}`, { method: 'PATCH', body: JSON.stringify({ body: next }) });
      });
    }
    messages.appendChild(item);
  });
  messages.scrollTop = messages.scrollHeight;
}

let toastTimer;

function showToast(message) {
  const toast = document.querySelector('#toast');
  toast.textContent = message;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.textContent = ''; }, 4000);
}

document.querySelector('#messageForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!state.activeId || form.dataset.sending === 'true') return;
  const input = document.querySelector('#messageInput');
  const body = input.value.trim();
  if (!body) return;
  const conversationId = state.activeId;
  const sendButton = document.querySelector('#sendButton');
  form.dataset.sending = 'true';
  sendButton.disabled = true;
  try {
    await api(`/api/conversations/${conversationId}/messages`, { method: 'POST', body: JSON.stringify({ body }) });
    input.value = '';
    if (state.activeId === conversationId) {
      await loadMessages(conversationId).catch(() => showToast('Message sent, but the conversation could not refresh.'));
    }
  } catch (error) {
    showToast(`Could not send message: ${error.message}`);
  } finally {
    form.dataset.sending = 'false';
    sendButton.disabled = false;
  }
});

async function searchPeople() {
  const q = document.querySelector('#peopleSearch').value;
  const data = await api(`/api/people?q=${encodeURIComponent(q)}`);
  const container = document.querySelector('#peopleResults');
  container.innerHTML = '';
  data.people.forEach((person) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.innerHTML = `<strong>${escapeHtml(person.name)}</strong><small>${escapeHtml(person.email)}</small>`;
    button.addEventListener('click', async () => {
      const result = await api('/api/conversations', { method: 'POST', body: JSON.stringify({ userId: person.id }) });
      document.querySelector('#newChatPanel').classList.add('hidden');
      await loadConversations();
      const conversation = state.conversations.find((item) => item.id === Number(result.conversationId));
      if (conversation) openConversation(conversation);
    });
    container.appendChild(button);
  });
}

['newChatButton', 'emptyNewChat', 'welcomeNewChat'].forEach((id) => {
  document.querySelector(`#${id}`).addEventListener('click', () => {
    document.querySelector('#newChatPanel').classList.toggle('hidden');
    searchPeople();
  });
});
document.querySelector('#closeNewChat').addEventListener('click', () => document.querySelector('#newChatPanel').classList.add('hidden'));
document.querySelector('#peopleSearch').addEventListener('input', searchPeople);
document.querySelector('#chatSearch').addEventListener('input', (event) => {
  const term = event.target.value.toLowerCase();
  renderConversations(state.conversations.filter((item) => item.other_name.toLowerCase().includes(term)));
});

function escapeHtml(value) {
  const element = document.createElement('div');
  element.textContent = value;
  return element.innerHTML;
}

boot();
